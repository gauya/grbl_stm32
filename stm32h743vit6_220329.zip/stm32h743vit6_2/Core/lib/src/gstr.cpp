/*
 * gstr.cpp
 *
 *  Created on: Dec 14, 2021
 *      Author: seu
 */

#include "gstr.h"

const char __default_white_space[] = " \t\n\r";
const char __default_delimiter[] = " \t\n\r,.:/";

void touppers(char *str) {
	while(*str) {
		*str = toupper(*str);
		str++;
	}
}

void tolowers(char *str) {
	while(*str) {
		*str = tolower(*str);
		str++;
	}
}

const char* whitespace_skip(const char *b)
{
	while( b && ((*b==' ')||(*b=='\t')||(*b=='\n')||(*b=='\r')) ) b++;
	return (b && *b)? b: (const char*)0;
}

const char *space_skip(const char *b,const char *s)
{
	if(s && *s)
		while(strchri(s,*b) != -1) b++;
	return b;
}

int strchri(const char *s,int ch) {
	if(!s || !ch) return -1;
	for(int i=0;*s; i++,s++) {
		if(*s == ch) return i;
	}
	return -1;
}

int cmpstr(const char *s,const char *d) {
	if( !s || !d ) return -1;

	for(;*s == *d;s++,d++) {
		if( !*s ) return 0;
	}
	return ((uint8_t)(*s) < (uint8_t)(*d))? -1 : 1;
}

int instrs(const char *s,const char **dest) {
	if(!s || !dest) return -1;

	for(int i=0;*dest;i++,dest++) {
		if( cmpstr(s,*dest) == 0 )
			return i;
	}
	return -1;
}


int stoi(const char *s) {
	s = whitespace_skip(s);
	if(!s) return 0;

	int minus = 1;
	uint32_t val = 0;

	if(*s == '-' || *s == '+')  {
		if(*s++ == '-') minus = -1;
	}

	for(;*s && (*s >= '0' || *s <= '9'); s++) {
		val = (val * 10) + (*s - '0');
	}
	//if( val & 0x80000000 ) // error

	return (minus ==-1)? -(int)val : (int)val;
}

double stof(const char *s) {
	s = whitespace_skip(s);
	if(!s) return 0.;

	int minus = 1;
	double v = 0;

	if(*s == '-' || *s == '+')  {
		if(*s++ == '-') minus = -1;
	}

	for(;*s && (*s >= '0' || *s <= '9'); s++) {
		v = (v * 10) + (*s - '0');
	}

	if(*s == '.') {
		int c;
		double d=1.0;
		for(c = 0; *s && (*s >= '0' || *s <= '9'); s++,c++) {
			d *= 0.1;
			v += d * (*s - '0');
		}
	}

	return (minus == -1)? -v : v;
}

int64_t stol(const char *s) {
	s = whitespace_skip(s);
	if(!s) return 0;

	int minus = 1;
	uint64_t val = 0;

	if(*s == '-' || *s == '+')  {
		if(*s++ == '-') minus = -1;
	}

	for(;*s && (*s >= '0' || *s <= '9'); s++) {
		val = (val * 10) + (*s - '0');
	}

	return (minus == -1)? -(int64_t)val : (uint64_t)val;
}

int istoktype(int ch) {
	if(!ch) return eEND;
	if(isalpha(ch)) return eALPA;
	if(isspace(ch)) return eSPACE;
	if(isdigit(ch)) return eNUM;
	if(strchr("+-*/%|&^=<>!~",ch)) return eOP;
	if(strchr("\"'`:;.,?@#$()[]{}_\\",ch)) return eDIL;
	return eERR;
}

/*
lev       =  1
lev     1
lev=  1
lev  =1

!!!!
lev ===  1
*/

const char *gettoken(const char *s, char *buf,int dilimeter,const char *space) {
	int cp = 0;

	buf[cp] = '\0';
	if(s) {
		s = space_skip(s,space);
		if( !s )
			return (const char *)0;
	}
	while(*s) {
		if(*s == dilimeter) {
			if(strchri(space,*s) != -1) { // deli && space
				s = space_skip(s,space);
				if(*s == dilimeter)
					s++;
			}
			s++;
			break;
		} else
			buf[cp++] = *s++;
	}
	buf[cp] = '\0';

	return space_skip(s,space);
}

const char *get_token(const char *s, char *buf) {
	int cp = 0;

	buf[cp] = '\0';
	s = whitespace_skip(s);
	if( !s )
		return (const char *)0;

	while(*s) {
		if(isspace(*s)) {
			break;
		}
		buf[cp++] = *s++;
	}
	buf[cp] = '\0';

	return whitespace_skip(s);
}

// return last field num index, -1 when error or not effective field
int str2arr(char *msg, char **dest, size_t sz, const char *dil) {
	int cnt=-1;

	while(*msg && cnt < (int)sz) {
		while(*msg && strchri(DEFAULT_WHITE_SPACE,*msg) != -1 ) msg++; // skip white space
		if( *msg == '\0' ) break;

		dest[++cnt] = msg;
		while(*msg && strchri(dil,*msg) == -1 ) msg++; // skip context
		if( *msg == '\0' ) break; // end

		*msg++ = '\0'; // must be *msg is dil or white space
	}

	return cnt;
}

// return array size
int str2arri(const char *msg, int16_t *dest, size_t sz, const char *dil) {
	size_t cnt,n;

	for(cnt=0;cnt < sz;cnt++)
		dest[cnt] = -1; // -1

	cnt = n = 0;
	dest[cnt++] = n;
	for(;*msg && (cnt < (sz-1));n++,msg++) {
		if(strchri(dil,*msg) != -1) {
			dest[cnt++] = n+1;
		}
	};

	return cnt;
}

// s1 > (n+1)
char *strnzcpy(char *s1, const char *s2, size_t n)
{
	char *s = s1;
	while (n > 0 && *s2 != '\0') {
		*s++ = *s2++;
		--n;
	}
	while (n > 0) {
		*s++ = '\0';
		--n;
	}
	*s = '\0';
	return s1;
}

int get_parse(const char **sp, char *buf) {
	const char *s = *sp;
	int cp = 0;
	int ot;

	s = whitespace_skip(s);
	if( !s ) {
		*sp = s;
		return -1;
	}
	ot = istoktype(*s);
	buf[cp++] = *s++;

	while(*s) {
		if((istoktype(*s)) != ot) {
			break;
		}
		buf[cp++] = *s++;
	}
	buf[cp] = '\0';

	*sp = whitespace_skip(s);
	return ot;
}

int
next_ch( const char** str )
{
	char ch = *(*str)++;
	if( ch == '\0' ) {
		(*str)--;
		return -1; // end
	}

	if( ch == 27 ) {
		ch = *(*str)++;
		switch(ch) {
		case '\0':
			(*str)--;
			return -1;
		case '\\': ch = '\\'; break;
		case 'r':	ch = '\r'; break;
		case 'n':	ch = '\n'; break;
		case 't':	ch = '\t'; break;
		case 'f':	ch = '\f'; break;
		case 'b':	ch = '\b'; break;
		default:
			;
		}
	}

	return (int)ch;
}

block_type __block_types[] = {
	{ eLINE_COMMENT, "//", "\n" },
	{ eCHAR_CONSTANT, "'", "'" },
	{ eCHAR_CONSTANT, "\"", "\"" },
	{ eCHAR_CONSTANT, "\"\"\"", "\"\"\"" },
	{ eCHAR_CONSTANT, "'''", "'''" },
	{ eBLOCK, "(", ")" },
	{ eBLOCK, "{", "}" },
	{ eBLOCK, "[", "]" },
	{ eCOMMENT, "/*", "*/" },
	{ eNOTBLOCK,}

};

int is_block(const char *str) {
	block_type *b = __block_types;

	for( ;b->etype != eNOTBLOCK; b++) {
		if(cmpstr(b->start,str) >= 0)
			return b->etype;
	}

	return -1;
}

int parse_block(block_type bt,const char **str,char *buf) {
	int c;
	char *s;

	s = strstr(*str,bt.end);
	if( !s ) return -1;

	c = (s - *str);
	strncpy(buf, *str, (s - *str));
	*str = s + strlen(bt.end);
	return c;
}


#ifdef __cplusplus

#include <stdexcept>
using namespace std;

gstr::gstr(const char *s) {
	// TODO Auto-generated constructor stub
	if(s) {
		_len = strlen(s);
		_str = new char[_len+1];
		if( !_str ) {
			// throw
		}
		strcpy(_str,s);
		_bsize = _len+1;
	} else {
		_str = 0;
		_len = 0;
		_bsize = 0;
	}
}

gstr::gstr(gstr &g) {
	// TODO Auto-generated constructor stub
	if(g.len() > 0) {
		_len = g.len();
		_str = new char[_len+1];
		if( !_str ) {
			// throw
		}
		strcpy(_str,g._str);
		_bsize = _len+1;
	} else {
		_str = 0;
		_len = 0;
		_bsize = 0;
	}
}

gstr::~gstr() {
	// TODO Auto-generated destructor stub
	if(_bsize > 0) {
		delete[] (_str);
	}
	_str = 0;
	_len = _bsize = 0;
}

gstr::operator const char*() const{
	return (const char*)_str;
}

gstr& gstr::operator=(gstr &g) {
	if( _bsize > 0 ) {
		delete[] _str;
	}
	if( g.len() > 0 ) {
		_str = new char[g.len()+1];
		_len = g.len();
		_bsize = g._len+1;
	} else {
		_str = 0;
		_len = 0;
		_bsize = 0;
	}
	return *this;
}
#include <string.h>

gstr& gstr::operator=(const char*s) {
	if( _bsize > 0 ) {
		delete[] _str;
		_bsize = _len = 0;
		_str = 0;
	}
	if( s ) {
		_len = strlen(s);
		_str = new char[_len+1];
		strcpy(_str,s);
		_bsize = _len + 1;
	} else {
		_str = 0;
		_len = 0;
		_bsize = 0;
	}
	return *this;
}
bool gstr::operator==(gstr &g) const {
	return (g.len() == len() && strcmp(g._str, _str) == 0)? true : false;
}

bool gstr::operator==(const char*s) const {
	return (strlen(s) == _len && strcmp(s, _str) == 0)? true : false;
}

char& gstr::at(int idx) {
	if( (uint32_t)idx < _len ) {
		return _str[idx];
	} else {
		//return _str[0];
		throw invalid_argument("MyFunc argument too large.");
//		throw std::out_of_range("");
//		throw std:: length_error(idx);
	}
}

char& gstr::operator [](int idx) {
	if( (uint32_t)idx < _len ) {
		return _str[idx];
	} else {
		throw std::out_of_range("");
	}
}

int gstr::comp (gstr& g) { // -1, 0, 1
	return strcmp(_str, g._str);
}

int gstr::comp (const char *s) { // -1, 0, 1
	return strcmp(_str,s);
}

gstr& gstr::append(gstr& g) {
	return append((const char*)g);
}

gstr& gstr::append(const char*s) {
	char *ns;
	uint32_t ln = strlen(s);
	if( ln == 0 ) return *this;

	int fb = _bsize - _len -1;
	if( fb < (int)ln ) {
		ns = new char[ln + len() + 1];
		strcpy(ns, _str);
		strcpy(ns+len(), s);

		if( _bsize > 0 )
			delete[] _str;
		_bsize = ln + len() + 1;
		_str = ns;
		_len += ln;
	} else {
		strcpy(_str + _len, s);
		_len += ln;
	}

	return *this;
}

gstr& gstr::operator += (gstr& g) {
	return append(g);

}

gstr& gstr::operator += (const char*s) {
	return append(s);
}

gstr& gstr::operator <<= (gstr& g) {
	return append(g);
}

gstr& gstr::operator <<= (const char* s) {
	return append(s);
}

gstr operator + (gstr& g1, gstr& g2) {
	gstr a = g1;
	a.append(g2);
	return a;
}

gstr operator + (gstr& g, const char* s) {
	gstr a(g);
	a.append(s);
	return a;
}

void gstr::lstrip(const char *d) {
	const char *s;
	if(!d) {
		s = whitespace_skip(_str);
	} else {
		s = space_skip(_str, d);
	}

	if( s != _str ) {
		// memcpy(
		uint32_t sz = (s - _str);
		for(int i=0; sz < _len; i++) {
			_str[i] = _str[sz++];
		}
		_str[sz] = '\0';
		_len -= (sz - 1);
		_bsize = 0;
	}
}

void gstr::rstrip(const char *d) {
	if( len() < 1 ) return;
	const char *p = (!d)? __default_white_space : d;
	for(; _len >= 0; _len--) {
		if( strchri(p,_str[_len]) == -1 ) {
			return;
		}
		_str[_len] = '\0';
		if(_bsize>=_len) _bsize = _len - 1;
	}
}

// strstr, strcasestr
gstr& gstr::remove(const char*ss) {
	if(!ss) return *this;
	char *s = strstr(_str,ss);
	if(!s) return *this;

	uint32_t ll=strlen(ss);

	strcpy(s, s+ll);
	_len -= ll;

	return *this;
}

gstr& gstr::remove_all(const char*ss) {
	if(!ss) return *this;
	char *s = strstr(_str,ss);
	if(!s) return *this;

	uint32_t ll=strlen(ss);

	do {
		strcpy(s,s+ll);
		s = strstr(s,ss);
	} while(s);

	_len = strlen(_str);

	return *this;
}

gstr& gstr::replace(const char*s1, const char*s2) {
	if(!s1) return *this;
	char *s = strstr(_str,s1);
	if(!s) return *this;

	if(!s2) return remove(s1);

	uint32_t l1=strlen(s1),l2=strlen(s2);

	auto scp = [](char*s,const char*s2){ while(*s2){ *s++ = *s2++; }; return s; };

	if( l1 == l2 ) {
		scp(s,s2);
		return *this;
	}

	if( l1 > l2 ) {
		const char *n = s + l1;
		s = scp(s,s2);
		s = scp(s,n);
		*s = '\0';

		_len -= (l1-l2);
		return *this;
	}

	char *nstr = new char[_len + l2 + 1];
	if(!nstr) return *this;

	char *np = nstr;
	strnzcpy(np,_str,(s - _str)); np += (s - _str);
	scp(np,s2); np += l2;
	strcpy(np,s+l1);

	if( _bsize > 0 ) delete _str;

	_bsize = _len + l2 + 1;
	_len = _len + (l2-l1);
	_str = nstr;

	return *this;
}

gstr& gstr::replace_all(const char*s1, const char*s2) {
	if(!s1) return *this;
	char *s = strstr(_str,s1);
	if(!s) return *this;

	if(!s2) return remove_all(s1);

	uint32_t l1=strlen(s1),l2=strlen(s2);

	auto scp = [](char*s,const char*s2){ while(*s2){ *s++ = *s2++; }; return s; };
	// l1 == l2
	if( l1 == l2 ) {
		scp(s,s2);
		return *this;
	}

	char *p1, *p2;
	// l1 > l2
	if( l1 > l2 ) {
		do {
			p2 = s + l2;
			p1 = s + l1;
			scp(s,s2);
			s = strstr(p1,s1);

		} while(s);
		strcpy(p2,p1);

		_len = strlen(_str);

		return *this;
	}

	char *nstr = new char[_len + l2 + 1];
	p2 = nstr;
	p1 = _str;
	int ln;
	do {
		ln = s-p1;
		strncpy(p2, p1, ln);
		s += l1;
		p1 = s;
		p2 += ln;
		strncpy(p2, s2, l2);
		p2 += l2;

		s = strstr(p1, s1);
	} while(s);
	if(!s) {
		strcpy(p2, p1);
	}

	if( _bsize > 0 ) delete _str;
	_bsize = _len + l2 + 1;
	_len = strlen(nstr);
	_str = nstr;

	return *this;
}

gstr& gstr::cut(int from, int to) {
	if( to < 0 ) to = _len - 1;
	if(from >= to || from < 0 || (uint32_t)to >= _len)
		return *this;

	strcpy(_str+from, _str+to+1);

	_len -= (to-from+1);

	return *this;
}

gstr& gstr::lower() {
	if( _len > 0 ) {
		for(uint32_t i=0;i<_len;i++) {
			_str[i] = tolower(_str[i]);
		}
	}
	return *this;
}

gstr& gstr::upper() {
	if( _len > 0 ) {
		for(uint32_t i=0;i<_len;i++) {
			_str[i] = toupper(_str[i]);
		}
	}
	return *this;
}

#endif // __cplusplus
