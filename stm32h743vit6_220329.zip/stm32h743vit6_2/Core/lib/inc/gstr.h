/*
 * gstr.h
 *
 *  Created on: Dec 14, 2021
 *      Author: seu
 */

#ifndef GSTR_H_
#define GSTR_H_

//#include <stddef.h>
#include <stdint.h>
#include <ctype.h>
#include <string.h>

#define DEFAULT_WHITE_SPACE " \t\n\r"

typedef enum {
	eALPA=0,
	eNUM,
	eOP,
	eDIL,
	eSPACE,
	eEND = -1,
	eERR = -2
} toktype;

typedef enum {
	eBLOCK=1,
	eLINE_COMMENT,
	eCOMMENT,
	eCHAR_CONSTANT,
	eNOTBLOCK
} eblock_type;

typedef struct {
	eblock_type etype;
	const char *start;
	const char *end;
} block_type;

#ifdef __cplusplus
extern "C" {
#endif

void touppers(char *str);
void tolowers(char *str);
const char* whitespace_skip(const char *b);
const char *space_skip(const char *b,const char *s);
int strchri(const char *s,int ch);
int cmpstr(const char *s,const char *d);
int instrs(const char *s,const char **dest);
int stoi(const char *s);
int64_t stol(const char *s);
double stof(const char *s);
int istoktype(int ch);

const char *gettoken(const char *s, char *buf,int dilimeter,const char *space);
const char *get_token(const char *s, char *buf);
int str2arr(char *msg, char **dest, size_t sz, const char *dil);
int str2arri(const char *msg, int16_t *dest, size_t sz, const char *dil);
char *strnzcpy(char *s1, const char *s2, size_t n);
int get_parse(const char **sp, char *buf);
int next_ch( const char** str );
int is_block(const char *str);
int parse_block(block_type bt,const char **str,char *buf);

#ifdef __cplusplus
}
//const char *get_token(const char *s, char *buf,int dilimeter=0,const char *space=0);
#endif

#ifdef __cplusplus

using namespace std;

class gstr {
	char *_str;
	uint32_t _len;
	uint32_t _bsize;
public:
	gstr(const char*s=0);
	gstr(gstr &);
	virtual ~gstr();
	inline uint32_t len() const { return _len; };
	operator const char*() const;
	gstr& operator=(gstr &);
	gstr& operator=(const char*);
	bool operator==(gstr &) const;
	bool operator==(const char*) const;
	char& at(int);
	char& operator [](int);
	int comp (gstr&); // -1, 0, 1
	int comp (const char *); // -1, 0, 1
	gstr& append(gstr&);
	gstr& append(const char*);
	gstr& operator += (gstr&);
	gstr& operator += (const char*);
	gstr& operator <<= (gstr&);
	gstr& operator <<= (const char*);
	friend gstr operator + (gstr&, gstr&) ;
	friend gstr operator + (gstr&, const char*) ;
	void lstrip(const char* d=0);
	void rstrip(const char *d=0);
	gstr& cut(int,int to=-1); // from to
	gstr& remove(const char*);
	gstr& remove_all(const char*);
	gstr& replace(const char*, const char*to=0);
	gstr& replace_all(const char*, const char*to=0);
	gstr& lower();
	gstr& upper();
};

#endif // __cplusplus
#endif /* GSTR_H_ */
