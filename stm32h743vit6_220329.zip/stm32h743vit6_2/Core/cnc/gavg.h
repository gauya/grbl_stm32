/*
 * gavg.h
 *
 *  Created on: 2021. 10. 14.
 *      Author: seu
 */

#ifndef GAVG_H_
#define GAVG_H_

#define DEF_GAVG_CALIBRATION 10

#include <stdint.h>
#include <float.h>

typedef struct {
	uint16_t cb,n;
	double  v;
} gavg_t;

typedef struct {
	uint16_t cb,n;
	uint16_t error;
	double  v;
	double max_l, min_l;
	double max_v, min_v;
} geavg_t;

#ifdef __cplusplus
extern "C" {
#endif

double gavg(gavg_t *k, double nv );
void set_gavg(gavg_t *k, uint16_t no);
double get_gavg(gavg_t *);

double geavg(geavg_t *k, double nv );
void set_geavg(geavg_t *k, uint16_t no, double amax, double amin);
double get_geavg(geavg_t *);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

class gavg : public geavg_t {
public:
	gavg(uint8_t calibrate = DEF_GAVG_CALIBRATION) {
		v = 0.;
		n = 0;
		cb = calibrate;
	}
	virtual ~gavg();

	double &val() { return v; }
	operator double() const {
		return v;
	}
	double in( double nv ) {
	    v = ( (v*n) + nv ) / (n+1);
	    if( n < cb ) n++;
	    return v;
	}
};

#endif // __cplusplus

#endif /* GAVG_H_ */
