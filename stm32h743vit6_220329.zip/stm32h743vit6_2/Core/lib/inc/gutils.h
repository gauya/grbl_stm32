/*
 * gutils.h
 *
 *  Created on: 2021. 10. 15.
 *      Author: seu
 */

#ifndef GUTILS_H_
#define GUTILS_H_

#ifndef BIT
#define BIT(n) (1 << (n))
#endif

#include <stdint.h>
#include <stddef.h>
#include <stdbool.h>
#include <float.h>

#define DEF_GAVG_CALIBRATION 10

typedef struct {
	uint16_t cb,n;
	double  v;
} gavg_t;

typedef struct {
	uint16_t cb,n;
	uint16_t error;
	double  v;
	double max_l, min_l;
	double max_v, min_v;
} geavg_t;

// max > min
typedef struct {
	double	max; //
	double	min; //
} fence_t;

#ifdef __cplusplus
extern "C" {
#endif

double fence( fence_t *p, double v );
uint32_t dif_u32(uint32_t s,uint32_t e);
uint32_t dif_u32_limit(uint32_t s,uint32_t e,uint32_t max);

double gavg(gavg_t *k, double nv );
void set_gavg(gavg_t *k, uint16_t no);
double get_gavg(gavg_t *);

double geavg(geavg_t *k, double nv );
void set_geavg(geavg_t *k, uint16_t no, double amax, double amin);
double get_geavg(geavg_t *);

#ifdef __cplusplus
}

#else // c

#ifndef bool
typedef enum {
	false = 0,
	true = 1
} bool;
#endif

#endif // cplusplus


#endif /* GUTILS_H_ */
