/*
 * app_etc.cpp
 *
 *  Created on: Mar 25, 2022
 *      Author: seu
 */

#include "app_etc.h"

int add_proc(const char*pn, void (*f)(const char*), int timer, int act) {
	int no = -1;
	if( timer != -1 ) {
		no = add_pfn( timer, (void(*)())f, pn);
		if( !act ) pfn_stop(no);
	}
	set_tty_func(pn,f);

	return no;
}

void scadule_pre() {
}

void scadule_post() {
	__HAL_IWDG_RELOAD_COUNTER(&hiwdg1);
}

void command_list(const char*str) {
	// ls --> void tty_inner_cmd_list()
	// ls -f view_proc()
	char bf[32];
	str = get_token(str, bf);
	if(!bf[0]) {
		tty_inner_cmd_list();
		return;
	}
	const char *cmds[] = { "-p","-a","-l",0 };
	switch( instrs(bf,cmds)) {
	case 1: case 2: // -a
		tty_inner_cmd_list();
	case 0: // -p
		view_proc();
		break;
	default:
		gdebug(2,0,"ls [-p | -a]\n");
	}
}

void scadule_traffic(const char *s) {
	scadule_info_t *sit = get_scadule_inf();
	if( !sit ) return;

	gdebug(2,0,"load %.1lfus (%.1lf ~ %.1lf)us\n"
			, sit->avg_long.v
			, sit->avg_long.max_v,sit->avg_long.min_v);
	sit->avg_long.max_v = DBL_MIN;
	sit->avg_long.min_v = DBL_MAX;
}

int ext_rt_proc_flag = 0;
void ext_rt_proc() {
	if(ext_rt_proc_flag) {
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_1);
	}
}

void system_reset(const char *s) {
	NVIC_SystemReset();
}

int tty_direct_func(int ch) {
	switch(ch) {
	case 'l':
		HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_1);
		break;
	default:
		  break;
	}
	return ch;
}

int tty_prev_func(int c) {
//	tty_func_key(c);
	return 0;
}

void clear_iwdg() {
	__HAL_IWDG_RELOAD_COUNTER(&hiwdg1);
}
