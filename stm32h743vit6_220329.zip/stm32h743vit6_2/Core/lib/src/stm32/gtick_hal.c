/*
 * gtick_stm32_hal.c
 *
 *  Created on: Dec 15, 2021
 *      Author: seu
 */

#include <stm32/gtick_hal.h>
#include "main.h"
#include "gproc.h"
#include "glog.h"

static eTick_vol __tick_vol = eTICK_VOL_100us;
static uint32_t __usec_per_intr;
static uint32_t __usec_max;
static uint32_t __ticks_per_usec;

static __IO uint32_t __sTicks = 0;
static __IO uint32_t __mTicks = 0;
static __IO uint32_t __uTicks = 0;

__IO uint32_t __test_cnt=0;
#ifdef __cplusplus
extern "C" {
#endif

#ifndef SysTick_VAL_Msk
#define SysTick_VAL_Msk 0xffffff
#endif

uint32_t get_tick() {
	return (uint32_t)(SysTick->VAL & SysTick_VAL_Msk);
}

uint32_t HAL_GetTick(void) {
	return __mTicks;
}

uint32_t get_utick() {
#if 1
	return (uint32_t)(get_tick() / __ticks_per_usec);
#else
	uint32_t t = get_tick();
	if( t < 128 ) t = 47999; //--> xx199, xx200

	uint32_t u = (uint32_t)(t / __ticks_per_usec);

	return u;
#endif
}

__attribute((__weak__)) void run_rtproc() {
	return;
}

/*
 *
start ../Core/lib/stm32/app.cpp
__tick_vol=10, __usec_max=47999, __usec_per_intr=100, __ticks_per_usec=480 0/0
sonar result = 0.685m (108,1057)
start ../Core/lib/stm32/app.cpp
__tick_vol=10, __usec_max=47999, __usec_per_intr=100, __ticks_per_usec=480 0/0
sonar result = 0.996m (107,1487)
---->    0 5 5 22
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0

1us
start ../Core/lib/src/stm32/app.cpp
__tick_vol=1000, __usec_max=479, __usec_per_intr=1, __ticks_per_usec=480 0/0

 */
#include "glog.h"
void init_ticks(eTick_vol vol) {
	__tick_vol = vol; // eTICK_VOL_10us; //eTICK_VOL_1us; // eTICK_VOL_1ms; // default eTICK_VOL_100us
	__usec_per_intr = 1000U / __tick_vol;
	__mTicks = 0;
	__uTicks = 0;

	HAL_SYSTICK_Config(SystemCoreClock / 1000U / __tick_vol);
	__usec_max = (uint32_t)(SysTick->LOAD & SysTick_VAL_Msk);
	__ticks_per_usec = __usec_max / (double)(__usec_per_intr) + 1;

	gdebug(3,0,"__tick_vol=%d, __usec_max=%lu, __usec_per_intr=%lu, __ticks_per_usec=%lu %lu/%lu\n"
			,__tick_vol, __usec_max, __usec_per_intr, __ticks_per_usec,__mTicks,__uTicks);
}

uint32_t get_stime() {
	return __sTicks;
}

uint32_t get_mtime() {
	return __mTicks;
}

uint32_t get_utime() {
//	return (__uTicks + (__usec_per_intr - ((SysTick->VAL & SysTick_VAL_Msk)/__ticks_per_usec) - 1));

	return (__uTicks + (__usec_per_intr - (get_utick() + 1)));
}
//extern IWDG_HandleTypeDef hiwdg1;

void HAL_IncTick(void) {
	static volatile uint16_t mcnt=0, lcnt=0, ucnt=0, err=0;

	__uTicks += __usec_per_intr;

	run_rtproc();

	if(++ucnt > __tick_vol) {
		ucnt = 0;
		__mTicks++;
		if(lcnt++ > 10) {
			if(get_scadule_laptime() > (LOOP_RESTRICT_TIME*1000)) { // 20ms
				// some more check function...
				//			__HAL_IWDG_RELOAD_COUNTER(&hiwdg1);
				if(err++ > 10) { //200ms Reset when an error occurs more than 10 times in a row
					// flash write
					NVIC_SystemReset();
				}
			} else {
				err = 0;
			}
			lcnt = 0;
		}
		if(++mcnt > 999 ) {
			__sTicks++;
			mcnt = 0;

		}
	}
}

#ifdef __cplusplus
}
#endif

