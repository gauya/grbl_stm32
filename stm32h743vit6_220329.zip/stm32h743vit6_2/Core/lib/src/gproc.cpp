/*
 * pfns.c
 *
 *  Created on: 2021. 12. 7.
 *      Author: seu
 */

#include "gproc.h"
#include "glog.h"
#include "gstr.h"
#include <stdlib.h>

typedef struct {
	gpfn_t *list[MAX_PFNS+1];
//	uint32_t alive;
	int pfns;
} pfnlist_t;

typedef struct {
	grtpfn_t *list[MAX_RTPFNS+1];
	int rtpfns;
} rtpfnlist_t;

static pfnlist_t __stp;
static rtpfnlist_t __rtp;

static uint16_t __restrict_time=0;
//static double __busyrate=0.0;

int gettps() { return __stp.pfns; }
int getrtps() { return __rtp.rtpfns; }

int init_pfn() {
	for(int i=0;i<MAX_PFNS; i++) {
		__stp.list[i] = 0;
	}
	__stp.pfns = 0;
	for(int i=0;i<MAX_RTPFNS; i++) {
		__rtp.list[i] = 0;
	}
	__rtp.rtpfns = 0;

	return 0;
}

int add_pfn(int prot, void (*pfn)(), const char*pname) {
	gpfn_t *g = (gpfn_t *)malloc(sizeof(gpfn_t));
	if( !g ) return -1;

	g->no = __stp.pfns;
	g->prot = prot;
	g->pfn = pfn;
	g->status = 0;
	g->load = 0;
	if( prot > 0) {
		set_timed(&g->tmd,prot);
	}
	strncpy(g->pname, pname, MAX_PFN_NAME_LEN);
	g->pname[MAX_PFN_NAME_LEN] = '\0';
	__stp.list[__stp.pfns] = g;

	__stp.pfns++;

	return (__stp.pfns - 1);
}

int add_rtpfn(int t, void (*rtpfn)()) {
	if( __rtp.rtpfns >= MAX_RTPFNS )
		return -1;

	grtpfn_t *r = (grtpfn_t *)malloc(sizeof(grtpfn_t));
	if( !r ) return -1;

	set_timed(&r->tmd, t);
	r->rtpfn = rtpfn;
	__rtp.list[__rtp.rtpfns] = r;
	__rtp.rtpfns++;

	return __rtp.rtpfns;
}

int pfn_setstatus(int id, int status) {
	gpfn_t *g = getpfn(id);
	if( !g ) return -1;

	g->status = status;
	return (int)status;
}

int pfn_stop(int id) {
	gpfn_t *g = getpfn(id);
	if( !g ) return -1;

	g->status |= 0x2;
	return 0;
}

int pfn_start(int id) {
	gpfn_t *g = getpfn(id);
	if( !g ) return -1;

	g->status &= ~0x2;
	return 0;
}


int pfn_settimer(int no, int ms) {
	gpfn_t *g = getpfn(no);
	if( !g ) return -1;

	if( ms > 0 ) {
		set_timed(&(g->tmd), ms);
		g->prot = ms;
	} else {
		g->prot = ms;
		set_timed(&(g->tmd), 0);
	}

	return 0;
}

static bool is_pfn(int no) {
	if( no < 0 || no >= __stp.pfns )
		return false;

	if( !__stp.list[no] || __stp.list[no]->status == -1 || ! __stp.list[no]->pfn )
		return false;
	else
		return true;
}

void view_proc() {
	int i;
	gpfn_t *g;
	grtpfn_t *r;

	int l = log_level(-1);
	gdebug(l,0,"tps total %d\n",gettps());

	for(i=0; i<MAX_PFNS; i++) {
		g = __stp.list[i];
		if( !g ) continue;
		gdebug(l,0,"%2d %7d '%12s' %10lu %s\n",g->no, g->prot, g->pname, g->load
				, (g->status == 0)? "Standby"
						: (g->status == 1)? "Running"
								: (g->status == 2)?  "Stoped"
										: (g->status == -1)? "Deleted"
												: "Unknown");
	}
	gdebug(l,0,"rtps total %d\n",getrtps());
	for(i=0; i<MAX_RTPFNS; i++) {
		r = __rtp.list[i];
		if( !r ) continue;
		gdebug(l,0,"%2d * %7dus rt proc\n", i,r->tmd.check);
	}
}

static void proc(gpfn_t *g) {
	if( g->status ) {
		return;
	}
	g->status |= 1;

	uint32_t pstime = get_utime();
	g->pfn();
	g->load = elapsed_us(pstime);

	g->status &= ~(1);
}

#define MAX_CMDS	10
void kill_proc(const char *s) {
	const char *optstr[] = { "-frq", "-f","-s","start","-k","stop", "-v","-h",0 };

	auto help = []{
			gdebug(2,0,
					"ps {-s|start|stop|-k} pid0,pid1,...\n"
					"ps {-f|-frq} pid frq(ms)\n"
					"ps -v\n"
					"ps [-h]\n"
					);
	};
	if(!s || !*s) {
		view_proc();
		return;
	}
	char *tb[MAX_CMDS];
	char buf[64]={0,};
	gpfn_t *g;

	strcpy(buf,s);

	int last_id = str2arr(buf,tb,MAX_CMDS," ,\t"); // return last index
	if( last_id < 0 ) {
		view_proc();
		return;
	}

	int idx = instrs(tb[0],optstr);
	if(idx < 0) {
		view_proc();
		return;
	}
	int cmd = 0;
	int pid,frq,rlt;
	switch(idx) {
	case 0: case 1: // change frequency
		pid = stoi(tb[1]);
		frq = stoi(tb[2]);
		rlt = pfn_settimer(pid, frq);
		gdebug(2,0,"change timer pid=%d timer=%lu %s\n", pid,frq
				,(rlt == -1)? "failed" : "success");
		return;
	case 2: case 3: // start
		cmd = 0;
		break;
	case 4: case 5: // stop
		cmd = 1;
		break;
	case 6:
		view_proc();
		return;
	default: //help
		help();
		return;
	}

	for(int i=1;i<=last_id;i++) {
		pid = stoi(tb[i]);
		if((g = getpfn(pid)) == 0) {
			gdebug(2,0,"%d) pid=%d is not", i, pid);
			continue;
		}
		if( g->no == 0 || g->pname[0] == '\0' ) {
			gdebug(2,0,"pid=0 or pname=null proc be prohibited\n");
			continue;
		}

		switch(cmd) {
		case 0:
			rlt = pfn_start(pid);
			gdebug(log_level(-1),0,"process %s[%d] start%s\n"
					, g->pname,pid,(rlt==-1)? " failed !!":"ed");
			break;
		case 1:
			rlt = pfn_stop(pid);
			gdebug(log_level(-1),0,"process %s[%d] stop%s\n"
					, g->pname,pid,(rlt==-1)? " failed !!":"ed");
			break;
		default:;
		}
	}
}

#undef MAX_CMDS

__attribute__((weak)) void ext_rt_proc() {
}

void run_rtproc() {
	grtpfn_t *r;

	ext_rt_proc();
	for( int i=0; i<__rtp.rtpfns; i++ ) {
		r = __rtp.list[i];
		if( is_timed_us(&(r->tmd))) r->rtpfn();
	}
}

static int run() {
	gpfn_t *g;
	int runs=0;
	int restrict_flag=0;
	int i;

	uint32_t stime = get_utime();
	for(i=0; i<__stp.pfns; i++) {
		if( is_pfn(i) == false ) continue;
		g = __stp.list[i];

 		if( g->prot <= 0 || (g->status & 0x3) ) continue;
 		if(  is_timed(&(g->tmd)) ) {
 			proc(g);

			if( restrict_flag == 0) {
				if( elapsed_us(stime) > __restrict_time ) {
					restrict_flag = 1;
				}
			}
	 		runs++;
		}
	}
	if( restrict_flag ) return runs;

	for(i=0; i<__stp.pfns; i++) {
		if( elapsed_us(stime) > __restrict_time ) {
			return runs;
		}

		g = __stp.list[i];
		if( !g ) continue;

 		if( g->prot <= 0 && (g->status & 0x3)==0 ) {
 			proc(g);

 			runs++;
		}
	}

	return runs;
}

gpfn_t *getpfn( int id ) {
	if( !is_pfn(id) ) return NULL;

	return __stp.list[id];
}

int getpfnid_byname( const char *pname ) {
	if( !pname ) return -1;
	for( int i=0;i < gettps(); i++ ) {
		if( !is_pfn(i) ) continue;
		if( strcmp(pname, __stp.list[i]->pname) == 0 ) {
			return i;
		}
	}
	return -1;
}

static int __runs = 0;
scadule_info_t __sit;

uint32_t get_scadule_laptime() {
	return elapsed_utime(__sit.stime,get_utime());
}

 scadule_info_t *get_scadule_inf() {
	return (scadule_info_t *)&__sit;
}

 __attribute__((weak)) void scadule_pre() {
 	return;
 }

 __attribute__((weak)) void scadule_post() {
	return;
 }

 void __scadule_pre() {
	 scadule_pre();
	__sit.stime = get_utime();
	return;
}

void __scadule_post() {
	scadule_post();
#ifdef DEBUG
	static int cnt=0;
	if( cnt++ >1000000) {
		uint32_t s = get_stime();
		int d,h,m;
		d = s / (24*3600); s -= d * (24*3600);
		h = s / 3600; s -= h * 3600;
		m = s / 60; s -= m * 60;
		gdebug(5,0,"loop load %5.2fus/%5.2fus elapsed %ddays %02d:%02d:%02d\n"
				,get_gavg(&__sit.avg_near),get_geavg(&__sit.avg_long)
				,d,h,m,s);
		cnt = 0;
	}
#endif
	__sit.etime = get_utime();

	uint32_t e = elapsed_utime(__sit.stime,__sit.etime);

	if( e > __restrict_time) {
#ifdef DEBUG
		uint32_t uu = get_utime();
		gdebug(5,0,"elapsed %lu - %lu/%lu - %lu\n", e, __sit.stime,__sit.etime,uu);
#endif
//		}

	} else {
		__sit.last_elapsedtime = (double)e;
		gavg(&__sit.avg_near, (double)e);
		geavg(&__sit.avg_long, (double)e);
	}
	if( __runs < __stp.pfns ) {
		// readjustment, large load pfn
	} else {
//		delay_us(1000 - (__sit.etime-__sit.stime));
//		delay_us(1);
	}
#if 0
	if( e < 10 ) delay_us(10);
#endif

	return;
}

void scadule() {
	__restrict_time = LOOP_RESTRICT_TIME;

	set_gavg(&__sit.avg_near,20);
	set_geavg(&__sit.avg_long,1000,0.,0.);

	while(1) {
		__scadule_pre();

		__runs = run();

		__scadule_post();
	}
}

