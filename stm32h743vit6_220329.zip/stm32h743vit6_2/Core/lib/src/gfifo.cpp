/*
 * gfifo.cpp
 *
 *  Created on: 2021. 10. 13.
 *      Author: seu
 */

#include <malloc.h>
#include <string.h>
#include "gfifo.h"

static int _fifo_isvalid(gfifo_t* f)
{
	return (f && (f->size > 1) && f->data && (f->cp < f->size) && (f->np < f->size) )? 1 : 0;
}

static int _fifo_isfull(gfifo_t* f)
{
	return (((f->cp + 1) == f->np) || (f->np == 0 && (f->cp == (f->size - 1))) );
}

static int _fifo_isempty(gfifo_t* f)
{
	return (f->cp == f->np);
}

int fifo_clear(gfifo_t* f)
{
	if( !_fifo_isvalid(f) )
		return -1;
	f->cp = f->np;

	return 0;
}

int fifo_getfree(gfifo_t* f)
{
	if( !_fifo_isvalid(f) ) return -1;

	if( f->cp <= f->np )
	{
		return (int)(f->np - f->cp);
	} else
	{
		return (int)(f->size - f->cp + f->np);
	}
}

static int _fifo_push(gfifo_t* f,int ch)
{
	if(f->lockfunc) f->lockfunc(1);

	if( _fifo_isfull(f) ) {
		if( !f->flag ) {
			ch = -1; //
		}
		if( f->flag == FIFO_DISTROY_NEW ) {
			ch = 0;
			f->overflow = 1;
		}
		if( f->flag == FIFO_WAIT ) {
			//while( fifo_isfull(f) );
			ch = -2;
		}
		if( f->flag == FIFO_DISTROY_OLD ) {
			if( ++(f->np) >= f->size ) f->np = 0; // old data destroy
			f->overflow = 1;
		}
	} else {
		f->data[f->cp] = (uint8_t)ch;
		if( ++(f->cp) >= f->size ) f->cp = 0;
	}

	if(f->lockfunc) f->lockfunc(0);

	return ch;
}

static int _fifo_pop(gfifo_t* f)
{
	int ch = 0;

	if(f->lockfunc) f->lockfunc(1);

	if( ! _fifo_isempty(f) )
	{
		ch = (int)f->data[f->np];
		if( ++(f->np) >= f->size ) f->np = 0;
	}
	f->overflow = 0;

	if(f->lockfunc) f->lockfunc(0);

	return ch;
}

int fifo_puts(gfifo_t* f,const char *buf)
{
	int i = 0,ch;
	if( _fifo_isvalid(f) == 0 )
		return -1;

	for( i = 0; buf[i]; i++ ) {
		ch = _fifo_push(f,(int)buf[i]);
		if( ch <= 0 || buf[i] == '\n' ) break;
	}

	return i;
}

int fifo_gets(gfifo_t* f,char *buf, uint16_t len)
{
	int ret = 0;
	if( _fifo_isvalid(f) == 0 || len < 2 )
		return -1;

	len -= 1;
	for( ret = 0; ret < len; ret++ ) {
		int val = _fifo_pop(f);
		if( val <= 0 ) break;
		buf[ret] = val;
		if( val == '\n' ) break;
	}
	buf[ret] = 0;

	return ret;
}


void fifo_init(gfifo_t* f, int bsize, int flag,void (*lockf)(int))
{
	memset(f->data,0,bsize);

	f->size = bsize;  // size << 1;
	f->cp = f->np = 0;
	f->flag = (flag == FIFO_WAIT || flag == FIFO_DISTROY_NEW || flag == FIFO_DISTROY_OLD )? flag : FIFO_DEF_MODE;
	f->overflow = 0;
	f->lockfunc = lockf;
}


int fifo_set(gfifo_t* f,uint8_t *buf, int size, int flag)
{
	if( !f ) return -1;
	if( buf ) {
		f->data = buf;
		f->alloc = 0;
	} else {
		if( size < 2 || size > FIFO_MAX_SIZE ) size = FIFO_MAX_SIZE;
		f->data = (uint8_t *)malloc(size+1);
		f->alloc = 1;
	}

	fifo_init(f, size, flag, 0 );

	return (int)size;
}

int fifo_reset(gfifo_t* f)
{
	if( ! f )
		return -1;
	if( f->alloc ) {
		free(f->data);
	}
	f->data = 0;
	f->size = f->flag = 0;
	f->cp = f->np = 0;
	f->overflow = 0;
	f->lockfunc = 0;

	return 1;
}

int fifo_putc(gfifo_t* f, int ch)
{
	if( !_fifo_isvalid(f) )
		return -1;

	return _fifo_push(f,ch);
}

int fifo_getc(gfifo_t* f)
{
	if( !_fifo_isvalid(f) )
		return -1;

	return _fifo_pop(f);
}

int fifo_write(gfifo_t* f,const uint8_t *buf, uint16_t len)
{
	if( ! _fifo_isvalid(f) )
		return -1;

	for( int i=0; i< len; i++ ) {
		if ( _fifo_push(f, buf[i]) <= 0 )
			return i;
	}

	return len;
}

int fifo_read(gfifo_t* f,uint8_t *buf, uint16_t len)
{
	if( ! _fifo_isvalid(f) )
		return -1;

	int ch;
	for( int i=0; i < len; i++) {
		if( (ch = _fifo_pop(f)) <= 0 )
			return i;
		buf[i] = (uint8_t)ch;
	}

	return len;
}

void fifo_setlock(gfifo_t* f, void (*lf)(int))
{
	if( ! _fifo_isvalid(f) )
		return;
	f->lockfunc = lf;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

template <typename T>
void gfifo<T>::debug(const char *s) const {
	printf("debug: [%s] size=%d cp/np=%d/%d flag=%x len=%u\n"
			,(s)? s : " ",_size,_cp,_np,_flags, length());
}

template <typename T>
bool gfifo<T>::isfull() {
	return (((_cp + 1) == _np) || (_np == 0 && (_cp == (_size - 1))) );
}

template <typename T>
bool gfifo<T>::isempty() {
	return (_cp == _np);
}

template <typename T>
void gfifo<T>::clear() {
	_cp = _np;
}

template <typename T>
bool gfifo<T>::lock() {
	if(_lock) return false;
	_lock = 1;
	return true;
}

template <typename T>
bool gfifo<T>::unlock() {
	if(_lock == 0) return false;
	_lock = 0;
	return true;
}

template <typename T>
int gfifo<T>::getfree() {
	if( _cp <= _np ) {
		return (int)(_np - _cp);
	} else {
		return (int)(_size - _cp + _np);
	}
}

template <typename T>
uint16_t gfifo<T>::length() const {
	uint16_t o = (_overflow)? 1 : 0;

	if( _cp > _np ) {
		return o + (_cp - _np);
	} else {
		return o + (_size - (_np - _cp));
	}
}

template <typename T>
uint16_t gfifo<T>::size() const {
	return _size;
}

template <typename T>
int gfifo<T>::pop(T val) {
	int ch = 1;
	if(lock() == false) return -1;;

	if( isfull() ) {
		if( _flag == 0 ) {
			ch = -1; //
		}
		if( _flag == FIFO_DISTROY_NEW ) {
			if( _overflow == 0 ) {
				_data[_cp] = val;
				_overflow = 1;
			}
			ch = 0;
		}
		if( _flag == FIFO_WAIT ) {
			//while( fifo_isfull(f) );
			ch = -2;
		}
		if( _flag == FIFO_DISTROY_OLD ) { // old data destroy
			_data[_cp] = val;
			if( _overflow == 0 ) {
				_overflow = 1;
			} else {
				if( ++(_cp) >= _size ) _cp = 0;
				if( ++(_np) >= _size ) _np = 0;
			}
		}
	} else {
		_data[_cp] = val;
		if( ++(_cp) >= _size ) _cp = 0;
	}

	unlock();
	return ch;
}

template <typename T>
T gfifo<T>::push()
{
	T ch = {0,};

	if(lock() == false) return ch;

	if( ! isempty() ) {
		ch = _data[_np];
		if( ++(_np) >= _size ) _np = 0;
		if(_overflow) {
			if( ++(_cp) >= _size ) _cp = 0;
			_overflow = 0;
		}
	}

	unlock();

	return ch;
}

template <typename T>
int gfifo<T>::push(T *buf) {
	*buf = {0,};

	if(lock() == false) return -1;

	if( ! isempty() ) {
		*buf = _data[_np];
		if( ++(_np) >= _size ) _np = 0;
		if(_overflow) {
			if( ++(_cp) >= _size ) _cp = 0;
			_overflow = 0;
		}
	}

	unlock();
	return (*buf)? 1 : 0;
}
/*
template <typename T>
gfifo<T>::operator gfifo_t *() { // dynamic_cast<Student *>(Person[i]);
return dynamic_cast<gfifo_t*>(this);
}

#include <stdlib.h>
#include <string.h>
*/
template <typename T>
gfifo<T>::gfifo(void) {
	_size = FIFO_MAX_SIZE;
	_data = (T*) new T[_size];

	_flags = 0;
	_alloc = 1;
	_flag = 2;
	_cp = _np = 0;
}

template <typename T>
gfifo<T>::gfifo(int len, int flag) : _size(len) {
	if( _size < 1 ) _size = FIFO_MAX_SIZE;
	_data = new T[_size];

	_flags = 0;
	_alloc = 1;
	_flag = flag;
	_cp = _np = 0;
}

template <typename T>
gfifo<T>::gfifo(T *buf, int len, int flag) : _size(len) {
	if( buf && _size > 0 ) {
		_data = buf; // extern buffer size may be larger then FIFO_MAX_SIZE
		_alloc = 0;
	} else {        // assert ?
		if( _size < 1 ) _size = FIFO_MAX_SIZE;
		_data = (T*) new T[_size];
		_alloc = 1;
	}
	_flags = 0;
	_flag = flag;
	_cp = _np = 0;
}

template <typename T>
gfifo<T>::~gfifo() {
	if(_size > 0 && _alloc)
		delete[] _data;
	_flags = 0;
	_size = _cp = _np = 0;
}

template <typename T>
int gfifo<T>::get(T ch) {
	return pop(ch);
}

template <typename T>
T gfifo<T>::put() {
	return push();
}

template <typename T>
int gfifo<T>::write(const T *buf, uint16_t len) {
	for( int i=0; i< len; i++ ) {
		if ( push(buf[i]) <= 0 )
			return i;
	}

	return _size;
}

template <typename T>
int gfifo<T>::read(T *buf, uint16_t len) {
	for( int i=0; i < len; i++) {
		if( (buf[i] = pop()) <= 0 )
			return i;
	}

	return len;
}

