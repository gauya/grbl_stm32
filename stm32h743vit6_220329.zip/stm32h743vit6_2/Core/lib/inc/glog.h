/*
 * glog.h
 *
 *  Created on: Dec 15, 2021
 *      Author: seu
 */

#ifndef GLOG_H_
#define GLOG_H_

#include <stdarg.h>
#include <stdio.h>

#define GDEBUG_BUFLEN	128

#ifdef __cplusplus
int log_level(int lev=-1);

extern "C" {
#endif

int gdebug(int lev, int where, const char* fmt, ...);

#ifdef __cplusplus
}
#endif

#ifdef __cplusplus

namespace std {

class glog final {
	int lev;
	int where;
public:
	glog(int lev = 0);
	virtual ~glog();
/*
	int log(const char *);
	int log(int where, const char *);
	int level(int lev=-1); // return lev
*/
};

} /* namespace std */

#endif // __cplusplus
#endif /* GLOG_H_ */
