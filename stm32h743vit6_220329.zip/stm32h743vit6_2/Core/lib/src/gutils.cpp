/*
 * gutils.cpp
 *
 *  Created on: 2021. 10. 15.
 *      Author: seu
 */

#include "gutils.h"

////////////////////////////////////////////////////////////////////
#ifdef __cplusplus
extern "C" {
#endif

double fence( fence_t *p, double v ) {
	//assert( p && (p->max > p->min) );
	if( v > p->max ) {
		v = p->max;
	} else
	if( v < p->min ) {
		v = p->min;
	}
	return (v / ( p->max - p->min )); // -1 ~ 1
}

uint32_t dif_u32(uint32_t s,uint32_t e) {
	return (uint32_t)(s > e)? (uint32_t)(0xffffffff - s + e) : (e - s);
}

uint32_t dif_u32_limit(uint32_t s,uint32_t e,uint32_t max) {
	return (uint32_t)(s > e)? ((max-s) + e) : (e-s);
}

double gavg( gavg_t* k, double nv )
{
    k->v = ( (k->v*(double)k->n) + nv ) / (double)(k->n+1);
    if( k->n < k->cb ) k->n++;

    return k->v;
}

void set_gavg(gavg_t *a, uint16_t no) {
	a->n = 0;
	a->v = 0.;
	a->cb = no;
}

double get_gavg(gavg_t *a) {
	return a->v;
}

double geavg( geavg_t* k, double nv )
{
	if( k->max_l < nv || k->min_l > nv) {
		if( k->error < 0xffff ) k->error++;
		return 0.;
	}

	k->v = ( (k->v*(double)k->n) + nv ) / (double)(k->n+1);
    if( k->n < k->cb ) {
    	k->n++;
    } else {
    	if( k->max_v < nv ) k->max_v = nv;
    	if( k->min_v > nv ) k->min_v = nv;
    }

    return k->v;
}

void set_geavg(geavg_t *a, uint16_t no, double amax, double amin) {
	a->n = 0;
	a->v = 0.;
	a->cb = no;
	a->error = 0;
	if(amax == amin) {
		a->max_l = DBL_MAX;
		a->min_l = DBL_MIN;
	} else {
		a->max_l = amax;
		a->min_l = amin;
	}
	a->max_v = DBL_MIN;;
	a->min_v = DBL_MAX;
}

double get_geavg(geavg_t *a) {
	return a->v;
}

#ifdef __cplusplus
}

#endif // __cplusplus

