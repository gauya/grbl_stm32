/*
 * glog.cpp
 *
 *  Created on: Dec 15, 2021
 *      Author: seu
 */

#include "glog.h"

#include <stdarg.h>

int _log_level = 0;
int gdebug(int lev, int where, const char* fmt, ...) {
	char buf[GDEBUG_BUFLEN];
	if( lev > _log_level ) return 1;
	if( where != 0 ) return 2;

	va_list ap;
	va_start(ap,fmt);
	vsnprintf(buf,GDEBUG_BUFLEN-1,fmt,ap);
	va_end(ap);

	switch(where) {
	case 0:
		printf(buf);
		break;
	default:
		return 2;
	}

	return 0;
}

int log_level(int lev) {
	if(lev != -1) {
		_log_level = lev;
	}
	return _log_level;
}

#ifdef __cplusplus

namespace std {

glog::glog(int lev) {
	// TODO Auto-generated constructor stub

}

glog::~glog() {
	// TODO Auto-generated destructor stub
}

} /* namespace std */

#endif
