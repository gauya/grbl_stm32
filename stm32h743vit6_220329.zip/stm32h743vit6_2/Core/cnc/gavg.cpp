/*
 * gavg.cpp
 *
 *  Created on: 2021. 10. 14.
 *      Author: seu
 */

#include "gavg.h"

////////////////////////////////////////////////////////////////////////////

double gavg( gavg_t* k, double nv )
{
    k->v = ( (k->v*(double)k->n) + nv ) / (double)(k->n+1);
    if( k->n < k->cb ) k->n++;

    return k->v;
}

void set_gavg(gavg_t *a, uint16_t no) {
	a->n = 0;
	a->v = 0.;
	a->cb = no;
}

double get_gavg(gavg_t *a) {
	return a->v;
}

double geavg( geavg_t* k, double nv )
{
	if( k->max_l < nv || k->min_l > nv) {
		if( k->error < 0xffff ) k->error++;
		return 0.;
	}

	k->v = ( (k->v*(double)k->n) + nv ) / (double)(k->n+1);
    if( k->n < k->cb ) {
    	k->n++;
    } else {
    	if( k->max_v < nv ) k->max_v = nv;
    	if( k->min_v > nv ) k->min_v = nv;
    }

    return k->v;
}

void set_geavg(geavg_t *a, uint16_t no, double amax, double amin) {
	a->n = 0;
	a->v = 0.;
	a->cb = no;
	a->error = 0;
	if(amax == amin) {
		a->max_l = DBL_MAX;
		a->min_l = DBL_MIN;
	} else {
		a->max_l = amax;
		a->min_l = amin;
	}
	a->max_v = DBL_MIN;;
	a->min_v = DBL_MAX;
}

double get_geavg(geavg_t *a) {
	return a->v;
}
