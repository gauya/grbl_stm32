
#include "main.h"
#include "stdint.h"

union axis5_steppins {
	uint16_t pins;
	struct {
		uint16_t pulse : 10;
		uint16_t limit : 5;
		uint16_t limit_dir : 1;
	};
	struct {
		uint16_t step : 5;
		uint16_t dir  : 5;
		uint16_t limits : 6;
	};
	struct {
		uint16_t x:1;
		uint16_t y:1;
		uint16_t z:1;
		uint16_t a:1;
		uint16_t b:1;
		uint16_t dx:1;
		uint16_t dy:1;
		uint16_t dz:1;
		uint16_t da:1;
		uint16_t db:1;
		uint16_t lx:1;
		uint16_t ly:1;
		uint16_t lz:1;
		uint16_t la:1;
		uint16_t lb:1;
		uint16_t : 1;
	};

	struct {
		uint16_t sx:2;
		uint16_t sy:2;
		uint16_t sz:2;
		uint16_t sa:2;
		uint16_t sb:2;
		uint16_t :6;
	};
};


union axis7_pins {
	uint16_t pins;
	struct {
		uint16_t step : 7;
		uint16_t dir  : 7;
		uint16_t :2;
	};
	struct {
		uint16_t x:1;
		uint16_t y:1;
		uint16_t z:1;
		uint16_t a:1;
		uint16_t b:1;
		uint16_t c:1;
		uint16_t d:1;
		uint16_t dx:1;
		uint16_t dy:1;
		uint16_t dz:1;
		uint16_t da:1;
		uint16_t db:1;
		uint16_t dc:1;
		uint16_t dd:1;
		uint16_t stepper_power:1;
		uint16_t :1;
	};
};

union axis7_pins_ins {
	uint16_t pins;
	struct {
		uint16_t limit :8;
		uint16_t sensor:8;
	};
	struct {
		uint16_t lx:1;
		uint16_t ly:1;
		uint16_t lz:1;
		uint16_t la:1;
		uint16_t lb:1;
		uint16_t lc:1;
		uint16_t ld:1;
		uint16_t dlimit:1;

		uint16_t probe  :1; // sensor
		uint16_t probe2 :1; // sensor
		uint16_t reset  :1; // button
		uint16_t cycle_start:1; // button
		uint16_t hold   :1; // button
		uint16_t stop   :1; // button
		uint16_t door   :1; // sensor
		uint16_t shock  :1; // sensor
	};
};

union axis8_pins {
	uint16_t pins;
	struct {
		uint16_t step : 8;
		uint16_t dir  : 8;
	};
	struct {
		uint16_t x:1;
		uint16_t y:1;
		uint16_t z:1;
		uint16_t a:1;
		uint16_t b:1;
		uint16_t c:1;
		uint16_t d:1;
		uint16_t e:1;
		uint16_t dx:1;
		uint16_t dy:1;
		uint16_t dz:1;
		uint16_t da:1;
		uint16_t db:1;
		uint16_t dc:1;
		uint16_t dd:1;
		uint16_t de:1;
	};
	struct {  // b0: signal, b1: direction
		uint16_t sx:2;
		uint16_t sy:2;
		uint16_t sz:2;
		uint16_t sa:2;
		uint16_t sb:2;
		uint16_t sc:2;
		uint16_t sd:2;
		uint16_t se:2;
	};
};

union axis8_pins_ds {
	uint16_t pins;
	struct {
		uint16_t pulse:8;
		uint16_t dir:8;
	};
	struct {
		uint16_t  x:1;
		uint16_t dx:1;
		uint16_t  y:1;
		uint16_t dy:1;
		uint16_t  z:1;
		uint16_t dz:1;
		uint16_t  a:1;
		uint16_t da:1;
		uint16_t  b:1;
		uint16_t db:1;
		uint16_t  c:1;
		uint16_t dc:1;
		uint16_t  d:1;
		uint16_t dd:1;
		uint16_t  e:1;
		uint16_t de:1;
	};
	struct {  // b0: signal, b1: direction
		uint16_t sx:2;
		uint16_t sy:2;
		uint16_t sz:2;
		uint16_t sa:2;
		uint16_t sb:2;
		uint16_t sc:2;
		uint16_t sd:2;
		uint16_t se:2;
	};
};

union control_pins {
	uint16_t	pins;
	struct {
		uint16_t in_pins:8;
		uint16_t out_pins:8;
	};
	struct {
		uint16_t probe  :1; // sensor
		uint16_t reset  :1; // button
		uint16_t cycle_start:1; // button
		uint16_t hold   :1; // button
		uint16_t shock  :1; // sensor
		uint16_t door   :1; // sensor
		uint16_t manual_mode:1; // button

		uint16_t heater :1;
		uint16_t light  :1;
		uint16_t plood  :1;
		uint16_t mist   :1;
		uint16_t air    :1;
		uint16_t tool_change:1; //
		uint16_t spindle:1;
		uint16_t stepper:1;
		uint16_t temp   :1; // sensor ,
	};
};

enum spindle_type_e {
	empty = -1,
	spindle = 0,
	laser,
	nozzle_3d,
	wire_thermal,
	wire_welding,
	nozzle_welding
};

union cnc_status {
	uint16_t	status;
	struct {
		uint16_t abort:1;   // emergency stoped , spindle power off, stepper only manual
		uint16_t home:1;    // homming,...
		uint16_t probe:1;   // homming
		uint16_t scan:1;    // scanning
		uint16_t tool:1;    // tool change

		uint16_t idle:1;    // power on, nothing gcode
		uint16_t stop:1;    // output power off but light and sensing .. is alive, gcode clear, can restart
		uint16_t pause:1;   // autostart( condition )
		uint16_t :2;
		uint16_t manual:1;  // manual mode
		uint16_t running:1;
	};
};

int32_t spindle_pwm = 0; // - , 0, + ,   min/max

TIM_TypeDef* const PST = TIM2; // stepper_pulse_start_timer
TIM_TypeDef* const PET = TIM3; // stepper_pulse_end_timer

gpio_t steppers = { GPIOB, 0 };
gpio_t controls = { GPIOA, 0 };

gpio_pin_t reset_pin = { GPIOA, 2 };

