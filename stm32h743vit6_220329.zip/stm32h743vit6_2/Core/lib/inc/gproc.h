/*
 * pfns.h
 *
 *  Created on: 2021. 12. 8.
 *      Author: seu
 */

#include <stdlib.h>
#include <string.h>
#include "gtick.h"
#include "gutils.h"

#ifndef INC_PFNS_H_
#define INC_PFNS_H_

#define MAX_PFNS 32
#define MAX_PFN_NAME_LEN 15
#define MAX_RTPFNS 8

// usecond 20ms
#define LOOP_RESTRICT_TIME (20000)

//#include "stm32f1xx_hal.h"

typedef struct {
	uint8_t no;
	uint8_t status;
	uint32_t prot; // 1~ : realtime
	timed_t tmd;
	uint32_t load; // usec
	void (*pfn)();
	char pname[MAX_PFN_NAME_LEN+1];
} gpfn_t;

typedef struct {
	timed_t tmd;
	uint32_t load;
	void (*rtpfn)();
} grtpfn_t;

typedef struct {
	int _runs;
	uint32_t stime,etime;
	gavg_t avg_near;
	geavg_t avg_long;
	double last_elapsedtime;
} scadule_info_t;

#ifdef __cplusplus
extern "C" {
#endif

int init_pfn();
int add_pfn(int prot, void (*pfn)(), const char*pname);
int add_rtpfn(int t, void (*rtpfn)());
gpfn_t *getpfn( int id );
int getpfnid_byname( const char *pname );
int gettps();
int getrtps();
int pfn_setstatus(int id, int status);
int pfn_stop(int id);
int pfn_start(int id);
void kill_proc(const char *s);
void proc_change_frq(const char *s);

int pfn_settimer(int no, int ms);
void run_rtproc();
void run_rtproc_all();
void view_proc();
void scadule();
scadule_info_t *get_scadule_inf();
uint32_t get_scadule_laptime();

#ifdef __cplusplus
}
#endif

#endif /* INC_PFNS_H_ */
