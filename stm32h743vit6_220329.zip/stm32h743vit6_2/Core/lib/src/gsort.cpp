/*
 * gsort.cpp
 *
 *  Created on: Nov 3, 2021
 *      Author: seu
 */

#ifdef __cplusplus

#include "gsort.h"

template <typename T>
int comp(T a, T b) {
	// T base variable type only
    return (a > b)? 1 : ( a == b )? 0 : -1;
//    return(strcmp(*(char **)arg1, *(char **)arg2));
// 	...
}

template <typename T>
void swap(T *a, T *b) {
    T v = *a;
    *a = *b;
    *b = v;
}

//
template <typename T>
void gsort_0(T *v, size_t size) {
	for( int i=0; i < (size-1); i++ ) {
		for( int k=i+1; k < (size-1); k++ ) {
			if( comp(v[i],v[k]) < 0 ) {
				swap(&v[i],&v[k]);
			}
		}
	}
}

// bubble
template <typename T>
void gsort_1(T *v, size_t size) {
	for( int i=0; i < (size-1); i++ ) {
		for( int k=i; k < (size-1); k++ ) {
			if( comp(v[k],v[k+1]) < 0 ) {
				swap(&v[k],&v[k+1]);
			}
		}
	}
}

// selection
template <typename T>
void gsort_2(T *v, size_t size) {
	for( int i=0; i < size; i++ ) {
		int p = i;
		for( int j=i+1; j < size; j++ ) {
			if( comp(v[p],v[j]) < 0 ) p = j;
		}
		if( i != p ) swap(&v[i], &v[p]);
	}
}

// insertion
template <typename T>
void gsort_3(T *v, size_t size) {
	for( int i=1; i < size; i++ ) {
		T p = v[i];
		int h=i;
		for( ; h > 0 && comp(v[h-1],p) > 0 ; h-- ) {
			v[h] = v[h-1];
		}
		v[h] = p;
	}
}

// merge

// quick

// #include <stdlib.h>
// qsort( void *v, size_t len, size_t width, int (*compf)( const void *, const void *);
// double ar[20] = { 0., ...  };
// qsort( (void*)ar, sizeof(ar)/sizeof(ar[0]), sizeof(ar[0]), compf );

template <typename T>
void gsort(T *v, size_t size, int type) {
	switch(type) {
	case SORT_BUBBLE:		return sort_1(v,size);
	case SORT_SELECTION:	return sort_2(v,size);
	case SORT_INSERTION:	return sort_3(v,size);
	}
	return sort_0(v,size);
}

#endif // __cplusplus

