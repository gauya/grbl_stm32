/*
 * uart_console.h
 *
 *  Created on: 2021. 10. 21.
 *      Author: seu
 */

#ifndef __GUART_HAL_H
#define __GUART_HAL_H

#include <stdio.h>
#include "main.h"

#define UART_INTERRUPT

#ifdef __cplusplus

extern "C" {
#endif

int __io_putchar(int ch);
int __io_getchar(void);
int _write(int32_t file, uint8_t *ptr, int32_t len);

void usart_reinit(UART_HandleTypeDef *hup,USART_TypeDef *USARTx, uint32_t brate,int console);
void uart_receive_it();
HAL_StatusTypeDef start_uart_console(UART_HandleTypeDef *phuart);

void set_uart_echo( int on );
int ugetc();
int uputc(int ch);
int uputs(const char* str);

#ifdef __cplusplus
}
#endif

#endif /* __GUART_HAL_H */
