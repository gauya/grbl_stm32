/*
 * cnc_test.cpp
 *
 *  Created on: 2022. 1. 20.
 *      Author: seu
 */

#include <stdint.h>
#include <math.h>
#include "cnc.h"

//32bit 0xffffffff , 4294967295, 21,474,836.47

float v, vmax, vmin;
float vx,vy;
int32_t l, lx,ly;
dir_e dx, dy;

float mm_per_step, angle_per_step;

int cx,cy,sx,sy;
int maxl;

// float step_per_mm_x, step_per_mm_x;

#define AXIS_STEP_GPIO GPIOC
#define AXIS_DIR_GPIO GPIOD

uint16_t bits_mask_step = 0;
uint16_t bits_mask_dir = 0;

uint16_t step_mask_bit[NAXIS];
uint16_t dir_mask_bit[NAXIS];

uint32_t ms,cs;

// 1 minute = (2 * PI) / (360*60) =  0.000290888
cnc_axis_info_t cai[] = {
		{ 0, "X", 0, 0.01},
		{ 0, "Y", 1, 0.01},
		{ 0, "Z", 2, 0.01},
		{ 1, "A", 3, 0.3}, // 1.8 / 6
		{ 1, "B", 4, },
		////////////////////////////////////
		{ 0x10, "E0", 5, },
		{ 0x10, "E1", 6, },
		{ 0x10, "E2", 7, },
		{ 0x11, "E3", 8, },         //
		////////////////////////////////////
		{ 0x20, "S0", 9, },         // spindle, on/off
		{ 0x21, "S1", 10, },         // spindle, direction, pwm
		////////////////////////////////////
		{ 0x30, "R0", 11, },         // laser
		{ 0x31, "R1", 12, },          // scanner
		{ 0xff, "", -1, }          //
};


pos_axis_t mk(int32_t *pos, int32_t *pre) { // length NAXIS
	pos_axis_t p;

	p.max_id = 0;
	uint32_t mx = 0;
	for(int i=0; i<NAXIS; i++) {
		p.axis[i].s = (pre[i] - pos[i]);
		if( mx < abs(p.axis[i].s)) {
			mx = p.axis[i].s;
			p.max_id = i;
		}
	}

	for(int i=0; i<NAXIS; i++) {
		p.axis[i].offs = p.axis[i].s / p.axis[max_id].s;
	}

	double d = 0.;
	for(int i=0; i<NAXIS; i++) {
		d += pow(p.axis[i].s, 2);
	}
	p.s = (uint32_t)sqrt(d);
	p.c = 0;

	return p;
}

gfifo<plan_t> gm;

uint16_t mk_step_dir_bit(axis_t *a) {
	uint16_t dir = 0; // all clear;

	for(int i=0; i<NAXIS; i++) {
		if(a->s >= 0) {
			dir |= step_mask_bit[i]; //
		}
	}
	return dir;
}

void timer_stepper() {
/* scenario
	- set_bit_dir();
	- delay_us(5); // 1~5us

	set_bit_step();
	start_finish_timer(); // 10~15us
*/

	plan_t *p;
	p = get_plan();
	if(!p) {
		mk_step_dir_bit();
		write_dir();
		return;
	}

	uint16_t dir = 0; step = 0, mask = 0;

	pos_axis_t *pa = p->p;
	axis_t *ax = pa->axis;
	for(int i=0; i<NISIX; i++) {
		ax[i].c += ax[i].offs;
		if(ax[i].c > 1.0) {
			step |= step_mask_bit[i];
			ax[i].c -= 1.0;
		}
	}
}

void timer_stepper_end() {
	write_stepper_pin(0); //	HAL_GPIO_WritePin(GPIOx, 0, PinState);
}
