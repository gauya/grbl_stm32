#include <stm32/guart_hal.h>
#include <string.h>

UART_HandleTypeDef *phuart_console = 0;
static int rx_echo = 1;
static int direct_key_mode = 0;

__attribute ((__weak__))int direct_key_func(int key) {
	return 0;
}

#include "gfifo.h"
#include <malloc.h>
static gfifo_t *__rx_fifo;

void fifo_lock(int s) {
	if ( s )
		phuart_console->Lock = HAL_LOCKED;
	else
		phuart_console->Lock = HAL_UNLOCKED;
}

/* usart printf */

int __io_putchar(int ch) {
	if( HAL_UART_Transmit(phuart_console, (uint8_t*)&ch,1,HAL_MAX_DELAY) == HAL_OK) return ch;
	// while( CDC_Transmit_FS((uint8_t*)&ch, 1) == USBD_BUSY);
	return -1;
}
int __io_getchar(void) {
	uint8_t ch;

	while(HAL_UART_Receive_IT(phuart_console, &ch, 1) != HAL_OK);

	return ch;
}

int _write(int32_t file, uint8_t *ptr, int32_t len)
{
	if( HAL_UART_Transmit(phuart_console, (uint8_t*)ptr,len,HAL_MAX_DELAY) == HAL_OK)
		return len;
    return 0;
}

/* usart interrupt */

// use after MX_USART1_UART_Init() function
//	start_uart_console(&huart1,1,1); ...

static uint8_t __rx_ch;
//static uint8_t __tx_ec;

void usart_reinit(UART_HandleTypeDef *hup,USART_TypeDef *USARTx, uint32_t brate, int console) {
	hup->Instance = USARTx;
	hup->Init.BaudRate = (brate == 0)? 115200 : brate;
	hup->Init.WordLength = UART_WORDLENGTH_8B;
	hup->Init.StopBits = UART_STOPBITS_1;
	hup->Init.Parity = UART_PARITY_NONE;
	hup->Init.Mode = UART_MODE_TX_RX;
	hup->Init.HwFlowCtl = UART_HWCONTROL_NONE;
	hup->Init.OverSampling = UART_OVERSAMPLING_16;
	hup->Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	hup->Init.ClockPrescaler = UART_PRESCALER_DIV1;
	hup->AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	HAL_UART_Init(hup);
	HAL_UARTEx_SetTxFifoThreshold(hup, UART_TXFIFO_THRESHOLD_1_8);
	HAL_UARTEx_EnableFifoMode(hup);
//	HAL_UARTEx_DisableFifoMode(hup);

	if( console ) {
		if( start_uart_console(hup) == HAL_ERROR ) {
			HAL_UART_Receive_IT(phuart_console,(uint8_t*)&__rx_ch,1);
		}
	}
}

void uart_receive_it() {
	HAL_UART_Receive_IT(phuart_console,(uint8_t*)&__rx_ch,1);
}

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if(huart->Instance == phuart_console->Instance) {
		if(direct_key_mode == 0 || direct_key_func(__rx_ch) == 0) {
			fifo_putc(__rx_fifo,__rx_ch);
		}
		if( rx_echo ) {
//			__tx_ec = __rx_ch;
			HAL_UART_Transmit(phuart_console,(uint8_t*)&__rx_ch,1,100); // echo
//			HAL_UART_Transmit_IT(phuart_console,(uint8_t*)&__tx_ec,1); // echo
		}
		HAL_UART_Receive_IT(phuart_console,(uint8_t*)&__rx_ch,1); // next recv interrupt enable
	}
}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
	if(huart->Instance == phuart_console->Instance) {
  	}
}

HAL_StatusTypeDef start_uart_console(UART_HandleTypeDef *phuart) {
	if(phuart_console)
		return HAL_ERROR;
	phuart_console = phuart;
	rx_echo = 1;
	__rx_fifo = malloc(sizeof(gfifo_t));
	fifo_set(__rx_fifo,0,0,0);
//		fifo_setlock(&__rx_fifo, fifo_lock);
	return HAL_UART_Receive_IT(phuart_console,(uint8_t*)&__rx_ch,1);
}

int ugetc() {
	return fifo_getc(__rx_fifo);
}

int uputc(int ch) {
	return __io_putchar(ch);
}

int uputs(const char* str) {
	return _write(0,(uint8_t*)str,(int32_t)strlen(str));
}

void set_uart_echo( int on ) {
	rx_echo = on;
}
