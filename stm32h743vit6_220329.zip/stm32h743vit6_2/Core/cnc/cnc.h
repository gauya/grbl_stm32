/*
 * cnc.h
 *
 *  Created on: Mar 5, 2022
 *      Author: seu
 */

#ifndef CNC_H_
#define CNC_H_

#include "stm32h7xx_hal.h"

// TB6600 ( 13~20khz ), DM542( 200khz )
//
#define MAX_STEP_PULSE_HZ	10000
#define MIN_STEP_PULSE_DURATION 2.5

// 1/100mm
#define PULSE_PER_MM 100
#define DEF_SPEED_RATE (0.5)

typedef enum {
	eL = -1,
	eLEFT = eL,
	eDOWN = eL,
	eM = 0,
	eSTOP = eM,
	eMIDDLE = eM,
	eR = 1,
	eRIGHT = eR,
	eUP = eR
} dir_e;

#define NAXIS 5

#ifdef __cplusplus
extern "C" {
#endif

typedef struct {
	int spindle_type;
	int tool;
	float speed;
	float spindle_speed;
	float bed_temperature;
	float nozzle_temperature[NNOZZLE];
	int spindle_dir;
	union {
		uint32_t modal_1;
		struct {
			uint32_t coolant : 1;
			uint32_t mist : 1;
			uint32_t blow : 1;
			uint32_t bed_sucker : 1;
			uint32_t bed_magnetic : 1;
			uint32_t heater : 1;
			uint32_t power : 1;
			uint32_t light : 1;
			uint32_t door : 1;
			uint32_t spindle : 1;
			uint32_t spindle_dir : 1;
			uint32_t  : 21;
		};
	};
	union {
		uint32_t modal_2;
		struct {
			uint32_t moving : 1; // G90/ G91
			uint32_t processing : 1;
			uint32_t coordinate_plate : 4; //G54~G58
			uint32_t  : 18;
		};
	};

} modal_t;

typedef struct {
	float pos[NAXIS];
	float speed;
	uint16_t gcode_no;
	uint16_t modal_id;
	union {
		uint32_t state;
		struct {
			uint32_t abort  :1;
			uint32_t handle :1;
			uint32_t stoped :1;
			uint32_t error  :1;
			uint32_t pause  :1; // wait 5 seconds
			uint32_t wait   :1; // ex) wait until the specified temperature
			uint32_t limit  :1;
			uint32_t homming:1;
			uint32_t probing:1;
			uint32_t tool   :1;
		};
	};
} state_t;

typedef union {
	uint32_t 	type;
	struct {
		uint32_t step_motor : 1;
		uint32_t brushless  : 1;
		uint32_t rotate     : 1;
		uint32_t reversible : 1;
		uint32_t speed_ctrl : 1;
		uint32_t laser    : 1;
		uint32_t extruder : 1;
		uint32_t spindle  : 1;
		uint32_t welder   : 1;
		uint32_t runner   : 1;
		uint32_t nozzle   : 1;
		uint32_t camera   : 1;
		uint32_t sensor   : 1;
		uint32_t heater   : 1;
	};
} axis_type_t;

typedef struct {
	uint32_t type;  // straight, rotate, spindle, extrude, laser,
	char name[4]; // 'X', 'Y','Z','A','B','C','R0','E','E0'
	uint8_t id;    //  0, 1, ...
	float umeter;    // um per pulse
	float seconds;   // degree per pulse
	float reduce;    // ratio reduce
	float power;     // motor power(W)
	float max_speed; // m/sec, rps(Hz)
	float inertia;
} driving_axis_info_t;

typedef struct {
	int32_t p[NAXIS]; // 10um
} pos_t;

typedef struct {
	int32_t s;   // goal from GCODE ( distance + direction )
	float c;     // c += offs > 1.0,
	float offs;  // positive(>=0), (axis[i].s / axis[max_axis_id].s)
} axis_t;

typedef struct {
	axis_t axis[NAXIS];
	uint8_t  max_id;

	uint32_t s; // real distance sqrt( pow(axis[i].s,2) + ,,, ), used calculate speed
	uint32_t c; // progress count
} pos_axis_t;

typedef struct {
	pos_axis_t *p;
	modal_t *m;
	uint16_t line;       // GCODE reference key
	uint16_t ln_sub;     // GCODE reference subkey - G02,G03,... G7x macro
} plan_t;

#if 0
gfifo<pos_t> *pos;
-> axis_t
-> pos_axis_t
-> plan_t

#endif

#ifdef __cplusplus
}
#endif

#endif /* CNC_H_ */
