/*
 * template_stm32_hal.c
 *
 *  Created on: 2021. 12. 8.
 *      Author: seu
 */

#include <app.h>
#include <stm32/gflash_hal.h>
#include "stm32h7xx_hal_gpio.h"
#include "stm32h7xx_hal_adc.h"
#include "stm32h7xx_hal_tim.h"
#include "stm32h7xx_hal_dma.h"
#include "stm32h7xx_hal_rcc.h"
uint32_t flash_test_data[128];

/*
 *
 * userled A1, button1/2 E3/C5
 * usb d-/d+ A11/A12
 * usart1 A9/A10
 * swd dio/clk A13/A14
 * tft SDI/SCL/CS/SD0/DC/BLK B15/B13/B12/B14/B1/B0
 * sdcard DAT2/CD/CMD/CLK/DAT0/DAT1 C10,C11,D2,C12,C8,C9
 *
 */
extern ADC_HandleTypeDef hadc1;
extern DMA_HandleTypeDef hdma_adc1;
extern ADC_HandleTypeDef hadc3;
extern DMA_HandleTypeDef hdma_adc3;
extern SPI_HandleTypeDef hspi1;
extern TIM_HandleTypeDef htim2;
extern TIM_HandleTypeDef htim3;
extern TIM_HandleTypeDef htim4;
extern RTC_HandleTypeDef hrtc;

uint16_t adc_val[64];
uint16_t adc_cnt=0;

uint16_t adc3_val[12];
uint16_t adc3_cnt=0;

void HAL_GPIO_EXTI_Callback( uint16_t pin ) {
	if(pin <= GPIO_PIN_6 ) { // limit axis
//		int gdir = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_15);
		switch(pin) {
		case GPIO_PIN_0:
			break;
		case GPIO_PIN_1:
			break;
		case GPIO_PIN_2:
			break;
		case GPIO_PIN_3:
			break;
		case GPIO_PIN_4:
			break;
		case GPIO_PIN_5:
			break;
		case GPIO_PIN_6:
			break;
		default:;
		}
/*
		int i;
		uint16_t ret=0x0;
		if( gdir ) ret = 0x100;
		for(i=0;i<7;i++) {
			if( pin & (1<<i) ) {
				ret += i;
			}
		}
*/
	} else {
		switch(pin) { // stop(emg), start, probe, door, pause,
		case GPIO_PIN_7:
			break;
		case GPIO_PIN_8:
			break;
		case GPIO_PIN_9:
			break;
		case GPIO_PIN_10:
			break;
		case GPIO_PIN_11:
			break;
		case GPIO_PIN_12:
			break;
		case GPIO_PIN_13:
			break;
		case GPIO_PIN_14:
			break;
		default:
			// ??
			break;
		}
	}
}

int rtc_alarm = 0;

void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc) {
	//HAL_GPIO_TogglePin(GPIOD, GPIO_PIN_15);
	rtc_alarm = 1;
}

int sonar_status = 0; // 0: idle, 1: trigger, 2: wait, 3: receive, 4: end
int sonar_cnt=0;
uint16_t ic_val1=0, ic_val2=0, ic_completed=0;
int tim3_int = 0,tim2_cnt=0;
uint32_t elapsed_time_tim3 = 0, last_elapsed=0;

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim) {
  if(htim->Instance == TIM4) // timeout
  {
	  sonar_status=10;
  }
  if(htim->Instance == TIM2) //
  {
	  tim2_cnt++;
	  // stepper_pulse_start();
	  TIM3->CNT = 0;
	  HAL_TIM_Base_Start_IT(&htim3);
	  elapsed_time_tim3 = get_utime();
  }
  if(htim->Instance == TIM3) //
  {
	  // stepper_pulse_end();
	  last_elapsed = elapsed_us(elapsed_time_tim3);
	  HAL_TIM_Base_Stop_IT(htim);
	  tim3_int++;
  }
}

void HAL_TIM_IC_CaptureCallback(TIM_HandleTypeDef *htim) {
	if(htim->Instance == TIM4) {
		if (htim->Channel == HAL_TIM_ACTIVE_CHANNEL_1) {
			if( ic_completed == 0 ) {
				ic_val1 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
				ic_completed = 1;
				HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_1);
			} else {
				ic_val2 = HAL_TIM_ReadCapturedValue(htim, TIM_CHANNEL_1);
				ic_completed = 3;
			}
		}
	}
}

int spi1_completed = 0, spi2_completed = 0;
int spi1_txcompleted = 0, spi2_txcompleted = 0;
uint8_t spi1_tx_data[16] = "Good morning!";
uint8_t spi1_rx_buf[16] = {0,};

uint8_t spi2_tx_data[16] = "Hello! baby.";
uint8_t spi2_rx_buf[16] = {0,};

void HAL_SPI_RxHalfCpltCallback(SPI_HandleTypeDef *hspi) {
	if(hspi->Instance == SPI1) {
		spi1_completed = 1;
	}
}

void HAL_SPI_TxHalfCpltCallback(SPI_HandleTypeDef *hspi) {
	if(hspi->Instance == SPI1) {
		spi1_txcompleted = 1;
	} else
	if(hspi->Instance == SPI2) {
		spi2_txcompleted = 1;
	}
}

void HAL_SPI_TxRxHalfCpltCallback(SPI_HandleTypeDef *hspi) {
	if(hspi->Instance == SPI1) {
	} else
	if(hspi->Instance == SPI2) {
	}
}

int adc3_seq=0;
void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef *hadc) {
	if( hadc->Instance == ADC1 ) {
		adc_cnt++;
#if 0
		not dma, single mode, interrupt,  one more channel
		static int idx = 0;
		if(idx++> Nchannels) idx=0;
		adc_val[idx] = HAL_ADC_GetValue(&hadc1); //
		// HAL_ADC_Start_IT(&hadc1); // single mode
#endif
	} else
	if( hadc->Instance == ADC3 ) {
		// ADC_CHANNEL_VBAT,ADC_CHANNEL_TEMPSENSOR,ADC_CHANNEL_VREFINT
		if( adc3_seq == 0 ) {
			adc3_val[0] = HAL_ADC_GetValue(&hadc3);
			adc3_seq = 1;
		} else
		if( adc3_seq == 1 ) {
			adc3_val[1] = HAL_ADC_GetValue(&hadc3);
			adc3_seq = 2;
		} else
		if( adc3_seq == 2 ) {
			adc3_val[2] = HAL_ADC_GetValue(&hadc3);
			adc3_seq = 0;
			HAL_ADC_Start_IT(&hadc3);
		}

		adc3_cnt++;
//		HAL_ADC_Start_IT(&hadc3);
	}
}
//
//sadc(23471) :    8470    2489    8512    2543    8492    2518    8486    2553   /   16730   16705   31272

void spi_loop_test() {
  __HAL_SPI_ENABLE(&hspi1);
//  __HAL_SPI_ENABLE(&hspi2);

  if(HAL_SPI_TransmitReceive_DMA(&hspi1, (uint8_t*)spi1_tx_data, (uint8_t *)spi1_rx_buf, 15) != HAL_OK)
 {
//    Error_Handler();
 }
/*
  if(HAL_SPI_Receive_DMA(&hspi2, (uint8_t *)spi2_rx_buf, 15) != HAL_OK)
  {
//    Error_Handler();
  }

  if(HAL_SPI_Transmit_DMA(&hspi2, (uint8_t *)spi2_tx_data, 15) != HAL_OK)
  {
//    Error_Handler();
  }
*/
//  while (HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY);
//  while (HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY);

 /*
	HAL_SPI_Transmit_DMA(&hspi1, spi1_tx_data, 15);
	HAL_SPI_TransmitReceive_DMA(&hspi1, spi1_tx_data, spi1_rx_buf, 15);
#if 0
	hspi1.State = HAL_SPI_STATE_READY;
	hspi2.State = HAL_SPI_STATE_READY;
#else
	while(HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY);
	while(HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY);
#endif

	HAL_SPI_Transmit_DMA(&hspi2, spi2_tx_data, 15);

#if 0
	hspi1.State = HAL_SPI_STATE_READY;
	hspi2.State = HAL_SPI_STATE_READY;
#else
	while(HAL_SPI_GetState(&hspi1) != HAL_SPI_STATE_READY);
	while(HAL_SPI_GetState(&hspi2) != HAL_SPI_STATE_READY);
#endif
	gdebug(2,0,"spi_rx_buf : [%16s]:%d/%d, [%16s]:%d/%d\n", spi1_rx_buf,spi1_completed,spi1_txcompleted,spi2_rx_buf,spi2_completed,spi2_txcompleted);
	spi1_completed = spi2_completed=spi1_txcompleted = spi2_txcompleted=0;
*/
}

void disp_adc_result() {
	gdebug(2,0,"adc(%u) : ",adc_cnt);
	for(int i=0;i<8;i++ ) {
		gdebug(2,0,"%7u ",adc_val[i]); adc_val[i] = 0;
	}
	gdebug(2,0,"  / ");
	for(int i=0;i<3;i++ ) {
		gdebug(2,0,"%7u ",adc3_val[i]); adc3_val[i] = 0;
	}
	gdebug(2,0,"\n");
}

void adc_restart() {
	// HAL_ADC_Start_IT(&hadc1); // single mode
	HAL_ADC_Start_DMA( &hadc1, (uint32_t *)adc_val, 8); // adc dma single
}

extern "C" {
int p_keys, p_test_p, p_test_2, p_view_proc_all, p_test_3, p_sonar;


} // extern "C"

#define SOUND_SPEED 331.5
#define SOUNDSPEED_TEMP_RATE 0.6
double temp=25.;
double clk_per_meter = (240*1000000 / 1000) / (double)((SOUND_SPEED + (SOUNDSPEED_TEMP_RATE * temp)) / 2);
double meter_per_clk = 1 / clk_per_meter;
gavg_t sona_gavg;

void sonar() {
	switch( sonar_status ) {
	case 0: // idle, ready, trigger
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
		delay_us(10);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_SET);
		delay_us(10);
		HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, GPIO_PIN_RESET);
		TIM4->CNT = 0;
		TIM4->CCR1 = 0;
		ic_completed = 0;
		ic_val1 = ic_val2 = 0;
		HAL_TIM_Base_Start_IT(&htim4);
		HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_1);
		sonar_status = 1;
		break;
	case 1: // wait echo
		if( ic_completed == 0x3 ) {
			uint32_t dval = ic_val2 - ic_val1;
			double clk_per_meter = (240*1000000 / 1000) / (double)((SOUND_SPEED + (SOUNDSPEED_TEMP_RATE * temp)) / 2);
			double meter_per_clk = 1 / clk_per_meter;
			gavg(&sona_gavg,meter_per_clk * dval);
			if((sonar_cnt % 1000) == 0)
				gdebug(2,0,"sonar result = %5.3fm (%u,%u)\n", get_gavg(&sona_gavg) ,ic_val1,ic_val2 );
			sonar_status = 2;
			sonar_cnt++;
		}
		break;
	default:
		if(sonar_status++ > 2) {
			sonar_status = 0;
		}
	}
}

volatile uint32_t ano_counter = 0;
volatile uint32_t test_rt_counter = 0;

void test_rt() {
	// 5ms
	test_rt_counter++;
}

void test_rt_2() {
	ano_counter++;
}

int pid=-1;

//test_2 4071325 50096395 adc=53766
void test_2() {
	gdebug(2,0,"test_2 %lu %lu adc=%u\n",ano_counter, test_rt_counter, adc_cnt );
}

void test_3() {
//	gprintf("my name %s test_rt = %lu %b\n","test_3", test_rt_counter,test_rt_counter);
	HAL_GPIO_TogglePin(GPIOA, GPIO_PIN_1);
//	gdebug(2,0,"my name %s test_rt = %lu\n","test_3", test_rt_counter);
}

void dis_sonar(const char*s) {
	gdebug(2,0,"sonar %5.3fm\n", get_gavg(&sona_gavg));
}

// ls
extern int ext_rt_proc_flag;
void ext_rt_proc_flag_set(const char *s) {
	ext_rt_proc_flag = (ext_rt_proc_flag)? 0 : 1;
}

void rtc_alarm_proc() {
	if(rtc_alarm) {
		gdebug(2,0,"rtc_alarm occurs\n");
		rtc_alarm = 0;
	}
}

/*
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
start ../Core/lib/src/stm32/app.cpp
sonar result = 0.652m (106,1009)
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
0
1
start ../Core/lib/src/stm32/app.cpp
2
3
4
5
sonar result = 0.674m (107,1040)
=>b, 76543, 3433.128, 258166
=>b, 76543, 3433.128, 258166
sonar result = 0.702m (106,1079)
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
flash_write addr=8020000 not
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0
flash_test
flash_write addr=8020000 not
=>6, 123456, 123433.125, [TOM] 287589667
__tick_vol=100, __usec_max=4799, __usec_per_intr=10, __ticks_per_usec=480 0/0


 */

struct sss {
	char c;
	int  i;
	float f;
	char n[5];
	uint32_t v;
//} ss = { 'b', 76543, 3433.1276, "", 0x3f076 };
} ss = { '6', 123456, 123433.1276, "", 0x11244523 };

struct sss sss_vv;

void flash_test() {
	for(int i=0;i<128;i++) {
		flash_test_data[i] = i;
	}
	strcpy(ss.n,"TOM");
//	flash_write(0x8020000,flash_test_data,128);
	gdebug(2,0,"flash_test\n");

	uint32_t addr = 0x8080000;
	flash_write(addr,(uint32_t*)&ss, sizeof(struct sss));
	gdebug(2,0,"=>%c, %d, %7.3f, [%.4s] %lu\n",
			ss.c, ss.i, ss.f, ss.n, ss.v);
	flash_read(addr, (uint32_t*)&sss_vv, sizeof(struct sss));
	sss_vv.n[4] = '\0';
	gdebug(2,0,"->%c, %d, %7.3f, [%.4s] %lu\n",
			sss_vv.c, sss_vv.i, sss_vv.f, sss_vv.n, sss_vv.v);
}

void setup(UART_HandleTypeDef *u) {
	start_uart_console(u);
	log_level(3);
	init_ticks(eTICK_VOL_10us); //eTICK_VOL_100us);

	init_rtc();
	init_pfn();

	gdebug(5,0,"start %s \n",__FILE__);
	clear_iwdg();


	if(check_pwr_flag()) {
		gdebug(2,0,"reboot from standby power mode\n");
	}

	HAL_ADC_Start_DMA( &hadc1, (uint32_t *)adc_val, 8);
	HAL_ADC_Start_IT(&hadc3);
	HAL_TIM_Base_Start_IT(&htim4);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_IC_Start_IT(&htim4, TIM_CHANNEL_1);

	add_pfn(100,rtc_alarm_proc,"");
	p_keys = add_pfn(0,tty,"");
	p_test_2 = add_pfn(1000,test_2,"test_2");
	p_test_3 = add_pfn(300,test_3,"test_3");
	p_sonar = add_pfn(10, sonar,"sonar_p");
	set_gavg(&sona_gavg,10);
	p_view_proc_all = pid=add_pfn(10000,view_proc,"process view");

	pfn_stop(p_test_2);
//	pfn_stop(p_test_3);
	pfn_stop(p_view_proc_all);

	add_rtpfn( 50, test_rt);
	add_rtpfn( 730, test_rt_2);

	set_tty_func("ps", kill_proc);
	set_tty_func("pwr", pwr_mode);
	set_tty_func("rtc",rtc);
	set_tty_func("reset",system_reset);
	add_proc("sonar", dis_sonar);
	add_proc("ls",command_list);
	add_proc("rttest",ext_rt_proc_flag_set);
	add_proc("load",scadule_traffic,10000);
//flash_test();
	log_level(10);
	clear_iwdg();

	scadule();
}

void loop() {
	clear_iwdg();
}

