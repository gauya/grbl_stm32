/*
 * gpid.h
 *
 *  Created on: 2021. 10. 19.
 *      Author: seu
 */

#ifndef GPID_H_
#define GPID_H_

#include <stdint.h>

#define USE_PID_TIMER -1

typedef struct {
	float	kp,ki,kd;
	float	pre_err,err,ierr,derr;
	float	setpoint, input;
// polling(NOUSE_PID_TIMER) or interrupt
#if (USE_PID_TIMER == -1)
	uint32_t	last_ms, elapsed;
#else
	float	dt;
#endif
//	float	max,min;
} gpid_t;

#include "gtick.h"

#ifdef __cplusplus
extern "C" {
#endif

void init_pid(gpid_t *pid, float p, float i, float d);
void set_pid(gpid_t *pid, float setpoint);
float get_pid(gpid_t *pid, float input);

#ifdef __cplusplus
}

using namespace std;

class gpid : private gpid_t {
public:
	gpid();
	gpid(float p, float i, float d);
	gpid(float p, float i, float d, float dt);
	~gpid();

	float setgoal(float sp);
	float pid(float in);

	double operator<<(double pv);
};

#endif // __cplusplus

#endif /* GPID_H_ */
