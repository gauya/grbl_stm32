/*
 * gpid.cpp
 *
 *  Created on: 2021. 10. 19.
 *      Author: seu
 */

#include "gpid.h"


#include <string.h>
#include "gutils.h"

#ifdef __cplusplus
extern "C" {
#endif

void init_pid(gpid_t *pid, float p, float i, float d) {
	memset((void*)pid, 0, sizeof(pid));
	pid->kp = p;
	pid->ki = i;
	pid->kd = d;
}

void set_pid(gpid_t *p, float setpoint) {
	p->setpoint = setpoint;
	p->err = p->pre_err = p->ierr = p->derr = 0;
}

float get_pid(gpid_t *p, float input) {
	p->input = input;
	p->err = p->setpoint - input;
#if (USE_PID_TIMER == -1)
	uint32_t m = get_mtime();
	p->elapsed = elapsed_ms(p->last_ms);
	p->last_ms = m;
	p->ierr += p->err * p->elapsed;
	p->derr = (p->err - p->pre_err) / p->elapsed;
#else
	p->ierr += p->err * p->dt;
	p->derr = (p->err - p->pre_err) / p->dt;
#endif
	p->pre_err = p->err;

	return (p->kp * p->err + p->ki * p->ierr + p->kd * p->derr);
}

#ifdef __cplusplus
}

gpid::gpid(float p, float i, float d) {
	kp = p;
	ki = i;
	kd = d;
	err = ierr = derr = pre_err = 0;
#if (USE_PID_TIMER == -1)
	last_ms = elapsed = 0;
#else
	dt = 1.;
#endif
}

gpid::gpid(float p, float i, float d, float dt) {
	kp = p;
	ki = i;
	kd = d;
	dt = dt;
	err = ierr = derr = pre_err = 0;
}

gpid::~gpid() {
}

float gpid::setgoal(float v) {
#if 0
	if( v > max ) v = max;
	if( v < min ) v = min;
#endif
#if (USE_PID_TIMER == -1)
	last_ms = elapsed = 0;
#endif
	setpoint = v;
	ierr = 0;

	return setpoint;
}

float gpid::pid(float in) {
	input = in;
	err = setpoint - input;
#if (USE_PID_TIMER == -1)
	uint32_t m = get_mtime();
	elapsed = elapsed_ms(last_ms);
	last_ms = m;
	ierr += err * elapsed;
	derr = (err - pre_err) / elapsed;
#else
	ierr += err * dt;
	derr = (err - pre_err) / dt;
#endif
	pre_err = err;

	return (kp * err + ki * ierr + kd * derr);
}

double gpid::operator<<(double pv) {
	return pid(pv);
}

#endif // __cplusplus
